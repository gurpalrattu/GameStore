<html>
<head>
	<style>
		th {
			font-weight: bold;
		}
		td {
			text-align: center;
			border-width: 2px;
			padding: 2px;
			height: 50px;
		}
	</style>
</head>
<p>
	<center><h1>Game Buy</h1>
	<h1>Title Search Results</h1></center>
	
	<hr/>
	
	<form>
	<table align="center" border="2px">
			<tbody>
			<tr>
				<td width="300px"><b>Title</b></td>
				<td width="200px"><b>Type</b></td>
				<td width="50px"><b>ID</b></td>
				<td width="175px"><b>Price/Copy</b></td>
				<td width="150px"><b>Quantity</b></td>
				<td width="100px"><b>Add to Cart</b></td>
			</tr>
			<?php

$search = $_POST['titlesearch'];
$color = "";
//select * from gametbl where(gme_type) in (('r'),('f')) and gme_title like '%halo%';

$myCon = mysqli_connect("localhost", "root", "", "gamestoredb");

if(mysqli_connect_errno())
{
	printf("Connection Failed: %s\n", mysqli_connect_error());
	exit();
}
else
{
	if(isset($_POST['genre']))
	{
		$strGenre = implode(",", $_POST['genre']);
	}
	else
	{
		$strGenre = "";
	}
	echo "Genre type: " . $strGenre;
	
	if(trim($search) == "")
	{
		$searchby = "";
	}
	else
	{
		if($_POST['searchby'] == "within")
		{
			$searchby = "WHERE gme_title LIKE '%$search%'";
		}
		elseif($_POST['searchby'] == "begin")
		{
			$searchby = "WHERE gme_title LIKE '$search%'";
		}
		else
		{
			$searchby = "WHERE gme_title='$search'";
		}
	}
	
	if($_POST['orderby'] == "title")
	{
		$query = "SELECT * FROM gametbl $searchby ORDER BY gme_title ";
	}
	else
	{
		$query = "SELECT * FROM gametbl $searchby ORDER BY gme_price DESC";
	}
	
	$runquery = mysqli_query($myCon, $query);
	
	$numrows = mysqli_num_rows($runquery);
	


			while($result = mysqli_fetch_assoc($runquery))
			{
				$id = $result['gme_id'];
				$title = $result['gme_title'];
				$type = $result['gme_type'];
				switch($type)
				{
					case 's':
					$type = "Simulation";
					$color = "orange";
					break;
					case 'f':
					$type = "First Person Shooter";	
					$color = "white";				
					break;
					case 'r':
					$type = "Real Time Strategy";
					$color = "yellow";
					break;
					case 'p':
					$type = "Role Play";
					$color = "salmon";
					break;
					case 't':
					$type = "Turn Based";
					$color = "pink";
					break;
				}
			
				$dateavail = $result['gme_date_avail'];
				$price = $result['gme_price'];
			
				
				
					echo "<tr>";
					echo "<td bgcolor='$color'>$title</td>";
					echo "<td>$type</td>";
					echo "<td>$id</td>";
					echo "<td>$price</td>";
					if($dateavail < date('Y-M-D'))
					{
						echo "<td>
							<select>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							</select>
						</td>";
						echo "<td><input type=\"checkbox\"></td>";
					}
					else
					{
						echo "<td>$dateavail</td>";
						echo "<td></td>";
					}
					
					
				echo "</tr>";
				}
				exit();
		}
			 ?>
		</tbody>
	</table>
	<br />
	<center><button type="submit">Submit</button><button type="reset">Clear</button></center>
	</form>
</p>
</html>
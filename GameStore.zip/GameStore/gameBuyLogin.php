<?php
// initializing the error messages
$error = array("", "", "");

// once login button pressed
if(isset ($_POST["login"]))
{
	// connection to database
	$myCon = mysqli_connect("localhost","root","","gamestoredb");
	
	// error message for failed connection
	if(mysqli_connect_errno()) 
	{
		printf ("Connection Failed: %s\n", mysqli_connect_error());
		exit();
	}
	else
	{
		// catching the username and password inputs
		$login = trim($_POST["username"]);
		$password = trim($_POST["password"]);
		
		// sql statement and running it through the database
		$query = "select * from customertbl where cust_lname = '$login' and cust_pass = '$password'";
		
		$runquery = mysqli_query($myCon, $query);
		
		if($runquery != FALSE)
		{
		// error checking to make sure username and password are okay
			if(trim($_POST["username"]) == "")
			$error[0] = "Your username is empty";
			elseif(strlen(trim($_POST["username"])) >= 20)
			$error[0] = "Your username is too long";
			
			if(trim($_POST["password"]) == "")
			$error[1] = "Your password is empty";
			elseif(strlen(trim($_POST["password"])) >= 8)
			$error[1] = "Your password is too long";
			

			else
			{
				// results from query to be used for cookies
				$result = mysqli_fetch_assoc($runquery);
				for($i = 1; $i <= mysqli_num_rows($runquery); $i++)
				{
					
				setcookie("fname", $result['cust_fname']);
				setcookie("lname", $result['cust_lname']);
				setcookie("id", $result['cust_id']);
				header("Location:titleSearch.php");
				
				exit();
				
				mysqli_close($myCon);
				}
				// message if login has failed
				$error[2] = "Login Incorrect, Please Try Again";
			}
 	 }
 	 // connection failure
 	 else
 		 print "problem ".mysqli_error($myCon);
 		 
 		 mysqli_close($myCon);
  }
}
?>

<html>
<p>
	<h1 align="center">Game Buy</h1> <br />
	<h2 align="center">Member Login</h2> <br />
	
	<table align="center">
	<!--posting information from form to self if not valid-->
	
	<form action="<?php print ($_SERVER['PHP_SELF']); ?>" method="POST">
		<tbody>
			<tr>
				<td align="right"><strong>Enter Your Lastname (MAX: 20 characters)</strong></td>
				
				<!--sends input to php validation, returns and prints if false-->
				
				<td><input type="text" name="username"
				value="<?php 
				if(isset($_POST["login"]))
					print($_POST["username"]);
				else
					print "";
				?>"/></td>
				<td><font color="red"><?php print $error[0]; ?></font></td>
			</tr>
			<tr>
				<td align="right"><strong>Enter your Password(7 characters)</strong></td>
				
				<!--sends input to php validation, returns and prints if false-->
				
				<td><input type="password" name="password" size="10"
				value="<?php
				if(isset($_POST["login"])) 
					print($_POST["password"]);
				else 
					print "";
				?>"/></td>
				<td><font color="red"><?php print $error[1]; ?></font></td>
			</tr>
			<tr align="center">
			
			<!--submit button and clear button-->
			
				<td colspan="3"><button type="submit" name="login">Login</button>
				<button type="reset">Clear</button></td>
			</tr>
		</tbody>
	</form>	
	</table>
	<br />
	<br />
	
	<center>
		<font color="red"><?php print $error[2]; ?></font>
	</center>
	
	<!--opens page for creating new account-->
	<form action="addNewCust.php">
		<center><font color="blue"><b>For New Members, Please Login Here: </b></font>
		<button type="submit">New Member</button></center>
	</form>
</p>
</html>
<?php

?>
<html>
<head>
	<style>
		table {
			border-style: inset;
		}
		tr, td {
			padding: 3px;
		}
	</style>
</head>
<p>
	<h1 align="center">Game Buy</h1>
	<h2 align="center">Welcome <?php echo ($_COOKIE['fname']); echo " "; echo($_COOKIE['lname']); ?></h2>
	<h1 align="center">Title Search</h1>
	
	<form method="POST" action="fetchDisplayGame.php">
	<table align="center" border="2px">
		<tbody>
			<tr>
				<td align="right" width="75px"><strong>Title</strong></td>
				<td colspan="3" align="center"><input type="text" size="40" name="titlesearch"></td>
				<td align="center" width="80px"><button type="submit" name="search">Search</button></td>
			</tr>
			<tr>
				<td rowspan="3"></td>
				<td align="right"><strong>Search By:</strong></td>
				<td><select name="searchby">
					<option value="begin">Begin With</option>
					<option selected="selected" value="within">Within Title</option>
					<option value="exact">Exact Match</option>
				</select></td>
				<td rowspan="3" width="275"><input type="checkbox" name="genre[]" value="f">First Person Shooter<br />
					<input type="checkbox" name="genre[]" value="p">Role Play<br />
					<input type="checkbox" name="genre[]" value="r">Real Time Strategy<br />
					<input type="checkbox" name="genre[]" value="s">Simulation<br />
					<input type="checkbox" name="genre[]" value="t">Turn Based<br />
					<strong>All Types(If NO check box is selected)</strong>
				</td>
				<td rowspan="3"></td>
			</tr>
			<tr>
				<td rowspan="2"></td>
				<td><input type="radio" name="orderby" value="title" checked="checked">
				<strong>Order By Title</strong></td>
			</tr>
			<tr>
				<td width="225px"><input type="radio" name="orderby" value="price">
				<strong>Order By Price(Highest)</strong></td>
			</tr>
			
		</tbody>
	</table>
	<br />
	<center><button type="reset">Clear</button></center>
	</form>
</p>
</html>
<?php
$error = array("", "", "", "", "");


if(isset($_POST["submit"]))
{
	$myCon = mysqli_connect("localhost", "root", "", "gamestoredb");
		
	if(mysqli_connect_errno())
	{
		printf ("Failed to connect: %s\n", mysqli_connect_error());
		exit();
	}
	else
	{
		$firstname = trim($_POST["firstname"]);
		$lastname = trim($_POST["lastname"]);
		$email = trim($_POST["email"]);
		$password = trim($_POST["password"]);
	
		$query = "select * from customertbl where cust_lname = '$lastname' and cust_pass = '$password'";
		
		$runquery = mysqli_query($myCon, $query);
		$record = mysqli_fetch_assoc($runquery);
	
		if($runquery !== FALSE)
		{
			if(trim($_POST["firstname"]) == "")
			$error[0] = "First Name can't be empty";
			elseif(trim(strlen($_POST["firstname"])) > 20)
			$error[0] = "Your First Name has too many characters";
			
			if(trim($_POST["lastname"]) == "")
			$error[1] = "Last Name can't be empty";
			elseif(trim(strlen($_POST["lastname"])) > 20)
			$error[1] = "Your Last Name has too many characters";
			
			if(trim($_POST["email"]) == "")
			$error[2] = "Email can't be empty";
			elseif(trim(strlen($_POST["email"])) > 20)
			$error[2] = "Your Email has too many characters";
			
			if(trim($_POST["password"]) == "")
			$error[3] = "Password can't be empty";
			elseif(trim(strlen($_POST["password"])) > 7)
			$error[3] = "Your Password has too many characters";
			elseif(trim(ctype_upper($_POST["password"])))
			$error[3] = "Invalid character";
			elseif(trim(is_numeric($_POST["password"])))
			$error[3] = "Your Password cannot be numeric";
			elseif(trim(is_numeric(substr($_POST["password"], 0, 1))))
			$error[3] = "Password cannot start with a number";
			
			if($record["cust_lname"] == $lastname && $record["cust_pass"] == $password) 
			$error[3] = "***Password is prohibited, please Re-enter***";	
			
			else
			{
				$insertquery = "insert into customertbl(cust_fname, cust_lname, cust_email, cust_pass) 
				values('$firstname','$lastname','$email','$password')";
				header("Location:titleSearch.php");
				
				setcookie("fname", $_POST["firstname"]);
				setcookie("lname", $_POST["lastname"]);
				setcookie("id", $_POST["id"]);
				exit();
				
				mysqli_close($myCon);
			}
		}
		else
 		 print "problem ".mysqli_error($myCon);
 		 
 		 mysqli_close($myCon);
	}
	
}
?>
<html>
<head>
	<style>
		table {
			border-style: inset;
		}
		tr, td {
			padding: 3px;
		}
	</style>
</head>
<p>
	<h1 align="center">Game Buy</h1>
	<h1 align="center">New Member</h1>	
	
	<br />
	<br />
	
	<form action="<?php print ($_SERVER['PHP_SELF']); ?>" method="POST">
	<table align="center" border="2px">
		<tbody>
			<tr>
				<td align="right">Enter Your <strong>First Name</strong>(Max 20 Chars)</td>
				<td width="300px"><input type="text" name="firstname" size="30px" 
				value="<?php 
				if(isset($_POST["submit"])) 
				  print($_POST["firstname"]);
				else
				  print "";
				?>"></td>
				<td><font color="red"><?php print $error[0]; ?></font></td>
			</tr>
			<tr>
				<td align="right">Enter Your <strong>Last Name</strong>(Max 20 Chars)</td>
				<td><input type="text" name="lastname" size="30px"
				value="<?php 
				if(isset($_POST["submit"])) 
				  print($_POST["lastname"]);
				else
				  print "";
				?>"></td>
				<td><font color="red"><?php print $error[1]; ?></font></td>
			</tr>
			<tr>
				<td align="right">Your <strong>E-mail</strong>(Max 20 Chars)</td>
				<td><input type="text" name="email" size="30px"
				value="<?php 
				if(isset($_POST["submit"])) 
				  print($_POST["email"]);
				else
				  print "";
				?>"></td>
				<td><font color="red"><?php print $error[2]; ?></font></td>
			</tr>
			<tr>
				<td align="right">
					Your <strong>Password</strong><br />
					<br />
					<ul><li>MUST BE 7 CHARACTERS</li><br />
					<li><strong>CANNOT</strong> BE ALL DIGITS</li><br />
					<li><strong>MUST BEGIN</strong> WITH A LETTER</li><br />
					<li><strong>ONLY LOWERCASE LETTERS</strong></li></ul>
				</td>
				<td><input type="text" name="password" size="15px"
				value="<?php 
				if(isset($_POST["submit"])) 
				  print($_POST["password"]);
				else
				  print "";
				?>"></td>
				<td><font color="red"><?php print $error[3]; ?></font></td>
			</tr>
			<tr>
				<td></td>
				<td><button type="submit" name="submit">Submit</button></td>
			</tr>
		</tbody>
	</table>
	</form>
	<font color="red"><?php print $error[4]; ?></font>
</p>
</html>